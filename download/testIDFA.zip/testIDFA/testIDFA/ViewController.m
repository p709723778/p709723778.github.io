//
//  ViewController.m
//  com.idreamsky.tests.sdk
//
//  Created by Soto.Poul on 2019/6/21.
//  Copyright © 2019 Soto.Poul. All rights reserved.
//

#import "ViewController.h"

@import AdSupport;

@interface ViewController ()
{
}

@property (nonatomic, weak) IBOutlet UILabel *lbl_IDFA;

@property (nonatomic, weak) IBOutlet UIButton *btn_GetIDFA;

@property (nonatomic, weak) IBOutlet UIButton *btn_ClearIDFA;

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (IBAction)getIDFA:(id)sender
{
    NSString *advertisingId = [[[ASIdentifierManager sharedManager] advertisingIdentifier] UUIDString];

    _lbl_IDFA.userInteractionEnabled = YES;
    _lbl_IDFA.text = [NSString stringWithFormat:@"IDFA: %@", advertisingId];

    UITapGestureRecognizer *tapGestureRecognizer = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(copyIDFA)];

    [_lbl_IDFA addGestureRecognizer:tapGestureRecognizer];
}

- (void)copyIDFA
{
    UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
    pasteboard.string = _lbl_IDFA.text;

    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"已放进粘贴板" message:_lbl_IDFA.text delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [alert show];
}

- (IBAction)isEnabledIDFA:(id)sender
{
    NSString *mgs = @"关闭";

    if ([[ASIdentifierManager sharedManager] isAdvertisingTrackingEnabled]) {
        mgs = @"开启";
    }
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"广告标识符(IDFA)开启状态" message:mgs delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [alert show];
}

@end
