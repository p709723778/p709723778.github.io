//
//  AppDelegate.h
//  com.idreamsky.tests.sdk
//
//  Created by Soto.Poul on 2019/6/21.
//  Copyright © 2019 Soto.Poul. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

